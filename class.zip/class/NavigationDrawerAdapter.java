package com.structure.appname.view.adapter;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.structure.appname.R;
import com.structure.appname.model.DrawerItem;

import java.util.List;


public class NavigationDrawerAdapter extends RecyclerView.Adapter<NavigationDrawerAdapter.MyViewHolder> {
    public SparseBooleanArray selectedItems;
int selected_position=0;
    List<DrawerItem> data;
    List<Integer>iconSlider;
    private LayoutInflater inflater;
    private Context context;

    public NavigationDrawerAdapter(Context context, List<DrawerItem> data) {
        this.context = context;
        inflater = LayoutInflater.from(context);
        this.data = data;
    }
    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.list_item_left_slider, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }



    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {
        if(selected_position == position){
            // Here I am just highlighting the background
            holder.itemView.setBackgroundColor(ContextCompat.getColor(context,R.color.toolbar_color));
            holder.title.setTextColor(ContextCompat.getColor(context, R.color.white));
            holder.sliderIcon.setImageResource(data.get(position).getHover_image());


        } else {
            holder.title.setTextColor(ContextCompat.getColor(context, R.color.black));
            holder.itemView.setBackgroundColor(ContextCompat.getColor(context, R.color.white));
            holder.sliderIcon.setImageResource(data.get(position).getImage_res());

        }
        holder.title.setText(data.get(position).getItem_name());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notifyItemChanged(selected_position);
                selected_position = position;
                notifyItemChanged(selected_position);
            }
        });


    }

    @Override
    public int getItemCount() {
        return data.size();
    }





    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        ImageView sliderIcon;
        RelativeLayout menu_item;

        public MyViewHolder(View itemView) {
            super(itemView);
            title = (TextView) itemView.findViewById(R.id.sliderTitle);
            sliderIcon=(ImageView)itemView.findViewById(R.id.sliderIcon);
            menu_item=(RelativeLayout)itemView.findViewById(R.id.menu_item);
        }
    }
}
