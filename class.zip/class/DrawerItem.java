package com.structure.appname.model;

/**
 * Created by ashishthakur on 6/9/16.
 */
public class DrawerItem {

    int image_res;
    int hover_image;
    String item_name;
    boolean isChecked=false;

    public DrawerItem(int image_res, String item_name, int hover_image){
        this.image_res=image_res;
        this.item_name=item_name;
        this.hover_image=hover_image;
    }

    public int getHover_image() {
        return hover_image;
    }

    public void setHover_image(int hover_image) {
        this.hover_image = hover_image;
    }

    public int getImage_res() {
        return image_res;
    }

    public int setImage_res(int image_res) {
        this.image_res = image_res;
        return image_res;
    }

    public String getItem_name() {
        return item_name;
    }

    public void setItem_name(String item_name) {
        this.item_name = item_name;
    }

    public boolean isChecked() {
        return isChecked;
    }

    public void setIsChecked(boolean isChecked) {
        this.isChecked = isChecked;
    }
}
