package com.structure.appname.view.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.facebook.FacebookSdk;
import com.facebook.login.LoginManager;
import com.structure.appname.R;
import com.structure.appname.prefs.MyPref;
import com.structure.appname.utils.AppConstants;
import com.structure.appname.utils.GUIManager;
import com.structure.appname.utils.StaticConstant;
import com.structure.appname.utils.Utils;
import com.structure.appname.view.fragment.AgentDetailFragment;
import com.structure.appname.view.fragment.ApprovedFragment;
import com.structure.appname.view.fragment.CampaignFragment;
import com.structure.appname.view.fragment.ContactUsFragment;
import com.structure.appname.view.fragment.FaqFragment;
import com.structure.appname.view.fragment.FragmentNavDrawer;
import com.structure.appname.view.fragment.HowItsWorkFragment;
import com.structure.appname.view.fragment.MyCampaignsFragment;
import com.structure.appname.view.fragment.MyProfileFragment;
import com.twitter.sdk.android.Twitter;

import java.io.File;
import java.io.IOException;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;


public class HomeActivity extends BaseActivity implements FragmentNavDrawer.FragmentDrawerListener {
    ActionBarDrawerToggle mDrawerToggle;
    FragmentNavDrawer fragmentNavDrawer;
    View containerView;
    @Bind(R.id.slider_button)
    public ImageView slider_button;
    @Bind(R.id.toolbar_title)
    public TextView toolbar_title;

    @Bind(R.id.page_text)
    public TextView page_text;
    @Bind(R.id.right_text_toolbar)
    public TextView right_text_toolbar;

    @Bind(R.id.backbutton)
    public ImageView backbutton;
    @Bind(R.id.toolbar)
    public Toolbar toolbar;
    @Bind(R.id.drawer_layout)
    public DrawerLayout drawerLayout;
    @Bind(R.id.main_layout)
    public RelativeLayout main;
    CampaignFragment campaignFragment;
    ApprovedFragment approvedFragment;


    public CampaignFragment getCampaignFragment() {
        return campaignFragment;
    }

    public void setCampaignFragment(CampaignFragment campaignFragment) {
        this.campaignFragment = campaignFragment;
    }

    public ApprovedFragment getApprovedFragment() {
        return approvedFragment;
    }

    public void setApprovedFragment(ApprovedFragment approvedFragment) {
        this.approvedFragment = approvedFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        ButterKnife.bind(this);
        afterChangeData();
        int currentapiVersion = android.os.Build.VERSION.SDK_INT;
        if (currentapiVersion >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            // Do something for lollipop and above versions
            Window window = HomeActivity.this.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(ContextCompat.getColor(getApplicationContext(), R.color.top_bar));
        } else {
            // do something for phones running an SDK before lollipop
        }
        MyPref.getInstance(HomeActivity.this).removePref(AppConstants.SOCIAL_LOGIN);
        pushFragments(new MyCampaignsFragment(), null, false);
        setUpToolbar();
        setNavagionDrawer();


        /*String fnameShared = "twitterShared" + ".jpg";
        String rootShared = Environment.getExternalStorageDirectory().toString() + "/imageTweet" + "/" + fnameShared;
        File imageFileShared = new File(rootShared);
        if (imageFileShared.exists()) {
            imageFileShared.delete();
        }*/
    }

    public interface Updateable {
        public void update();
    }

    @OnClick({R.id.slider_button, R.id.toolbar})
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.slider_button:
                slideDrawer();
                break;
            case R.id.toolbar:
                break;

        }

    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String from = "";
        try {
            from = intent.getStringExtra(AppConstants.FROM);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (from != null) {
            if (from.equalsIgnoreCase("ratecard")) {
                pushFragments(new AgentDetailFragment(), null, false);

            }
        }

    }

    @Override
    public void onBackPressed() {
        GUIManager.backManageHandler(HomeActivity.this);
    }

    public void setUpToolbar() {
        // Set a toolbar to replace the action bar.
        backbutton.setVisibility(View.GONE);
        right_text_toolbar.setVisibility(View.GONE);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setElevation(0);
    }

    public void setNavagionDrawer() {
        fragmentNavDrawer = (FragmentNavDrawer) getSupportFragmentManager().findFragmentById(R.id.fragment_navigation_drawer);
        fragmentNavDrawer.setUp(R.id.fragment_navigation_drawer, drawerLayout, toolbar);
        fragmentNavDrawer.setDrawerListener(this);
        drawerLayout.addDrawerListener(mDrawerToggle);
        drawerLayout.addDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                main.setTranslationX(slideOffset * drawerView.getWidth());
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                closeKeyboardForceFully();
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                closeKeyboardForceFully();
            }

            @Override
            public void onDrawerStateChanged(int newState) {

            }
        });
    }

    public void slideDrawer() {
        containerView = findViewById(R.id.fragment_navigation_drawer);

        if (!drawerLayout.isDrawerOpen(containerView))
            drawerLayout.openDrawer(containerView);
        else
            drawerLayout.closeDrawer(containerView);
    }

    public void setTitle(String title) {
        toolbar_title.setText(title);
    }

    public void setPageTitle(String title) {
        page_text.setText(title);
    }
    public void setEnableCheck(boolean isTrueFalse){
        backbutton.setEnabled(isTrueFalse);
    }
    public void setEnableRightText(boolean isTrueFalse){
        right_text_toolbar.setEnabled(isTrueFalse);
    }


    @Override
    public void onDrawerItemSelected(View view, int position) {
        switch (position) {

            case 0:
                pushFragments(new MyCampaignsFragment(), null, false);
                break;
            case 1:
                pushFragments(new MyProfileFragment(), null, false);
                break;
            case 2:
                pushFragments(new HowItsWorkFragment(), null, false);
                break;
            case 3:
                pushFragments(new FaqFragment(), null, false);
                break;
            case 4:
                pushFragments(new ContactUsFragment(), null, false);
                break;
            case 5:
                logoutAlert();
                break;
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        for (android.support.v4.app.Fragment fragment : getSupportFragmentManager().getFragments()) {
            if (fragment != null) {
                fragment.onActivityResult(requestCode, resultCode, data);
            }
        }

    }

    public void LogOut() {
        File dir = new File(Environment.getExternalStorageDirectory().toString()+"/twitter");
        if (dir.isDirectory())
        {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++)
            {
                new File(dir, children[i]).delete();
            }
        }

        File dirfacebook = new File(Environment.getExternalStorageDirectory().toString()+"/facebook");
        if (dirfacebook.isDirectory())
        {
            String[] children = dirfacebook.list();
            for (int i = 0; i < children.length; i++)
            {
                new File(dirfacebook, children[i]).delete();
            }
        }
        File dirInsta = new File(Environment.getExternalStorageDirectory().toString()+"/instagram");
        if (dirInsta.isDirectory())
        {
            String[] children = dirInsta.list();
            for (int i = 0; i < children.length; i++)
            {
                new File(dirInsta, children[i]).delete();
            }
        }
        File dirInstaShared = new File(Environment.getExternalStorageDirectory().toString()+"/InstagramShared");
        if (dirInstaShared.isDirectory())
        {
            String[] children = dirInstaShared.list();
            for (int i = 0; i < children.length; i++)
            {
                new File(dirInstaShared, children[i]).delete();
            }
        }
        File dirtweetShared = new File(Environment.getExternalStorageDirectory().toString()+"/twittershared");
        if (dirtweetShared.isDirectory())
        {
            String[] children = dirtweetShared.list();
            for (int i = 0; i < children.length; i++)
            {
                new File(dirtweetShared, children[i]).delete();
            }
        }
        File fbShared = new File(Environment.getExternalStorageDirectory().toString()+"/facebookshared");
        if (fbShared.isDirectory())
        {
            String[] children = fbShared.list();
            for (int i = 0; i < children.length; i++)
            {
                new File(fbShared, children[i]).delete();
            }
        }

        MyPref.getInstance(HomeActivity.this).removePref("isSharedTwitter");
        MyPref.getInstance(HomeActivity.this).removePref("isSharedFacebook");
        MyPref.getInstance(HomeActivity.this).removePref("isSharedInstagram");

        MyPref.getInstance(HomeActivity.this).removePref("isPosted");
        MyPref.getInstance(HomeActivity.this).removePref("isPostedFB");
        MyPref.getInstance(HomeActivity.this).removePref("isPostedIN");

        MyPref.getInstance(HomeActivity.this).removePref("twitter_field");
        MyPref.getInstance(HomeActivity.this).removePref("instagram_field");
        MyPref.getInstance(HomeActivity.this).removePref("facebook_field");


        MyPref.getInstance(HomeActivity.this).removePref(AppConstants.INSTAGRAM_TOKEN);
        MyPref.getInstance(HomeActivity.this).removePref(AppConstants.FACEBOOK_TOKEN);
        MyPref.getInstance(HomeActivity.this).removePref(AppConstants.TWEETER_TOKEN);
        MyPref.getInstance(HomeActivity.this).removePref(AppConstants.FACEBOOKPROFILE_PIC_URL);
        MyPref.getInstance(HomeActivity.this).removePref(AppConstants.TWEETER_PIC_URL);
        MyPref.getInstance(HomeActivity.this).removePref(AppConstants.FACEBOOK_NAME);
        MyPref.getInstance(HomeActivity.this).removePref(AppConstants.TWEETER_NAME);
        MyPref.getInstance(HomeActivity.this).removePref(AppConstants.INSTAGRAM_PIC_URL);
        MyPref.getInstance(HomeActivity.this).removePref(AppConstants.INSTAGRAM_NAME);
        MyPref.getInstance(HomeActivity.this).readPrefs(AppConstants.SOCIAL_LOGIN);
        LoginManager.getInstance().logOut();
        Twitter.logOut();

        startActivity(new Intent(HomeActivity.this, LoginActivity.class));
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        afterChangeData();
        boolean check = MyPref.getInstance(HomeActivity.this).readBooleanPrefs("isCampainDetailActivity");
        if (check) {
            pushFragments(new MyCampaignsFragment(), null, false);
            MyPref.getInstance(HomeActivity.this).writeBooleanPrefs("isCampainDetailActivity",false);
        }
        //  pushFragments(new MyCampaignsFragment(), null, false);
    }

    public void afterChangeData() {

        String facename = "facebook_image" + ".jpg";
        String rootFace = Environment.getExternalStorageDirectory().toString() + "/facebook" + "/" + facename;
        File imageFileFacebook = new File(rootFace);
        if (imageFileFacebook.exists()) {
            imageFileFacebook.delete();
        }
        File dir = new File(Environment.getExternalStorageDirectory().toString()+"/twitter");
        if (dir.isDirectory())
        {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++)
            {
                new File(dir, children[i]).delete();
            }
        }
        File dirInsta = new File(Environment.getExternalStorageDirectory().toString()+"/instagram");
        if (dirInsta.isDirectory())
        {
            String[] children = dirInsta.list();
            for (int i = 0; i < children.length; i++)
            {
                new File(dirInsta, children[i]).delete();
            }
        }
        File dirInstaShared = new File(Environment.getExternalStorageDirectory().toString()+"/InstagramShared");
        if (dirInstaShared.isDirectory())
        {
            String[] children = dirInstaShared.list();
            for (int i = 0; i < children.length; i++)
            {
                new File(dirInstaShared, children[i]).delete();
            }
        }
        File dirtweetShared = new File(Environment.getExternalStorageDirectory().toString()+"/twittershared");
        if (dirtweetShared.isDirectory())
        {
            String[] children = dirtweetShared.list();
            for (int i = 0; i < children.length; i++)
            {
                new File(dirtweetShared, children[i]).delete();
            }
        }

        MyPref.getInstance(HomeActivity.this).removePref("isSharedTwitter");
        MyPref.getInstance(HomeActivity.this).removePref("isSharedFacebook");
        MyPref.getInstance(HomeActivity.this).removePref("isSharedInstagram");

        MyPref.getInstance(HomeActivity.this).removePref("isPosted");
        MyPref.getInstance(HomeActivity.this).removePref("isPostedFB");
        MyPref.getInstance(HomeActivity.this).removePref("isPostedIN");

        MyPref.getInstance(HomeActivity.this).removePref("twitter_field");
        MyPref.getInstance(HomeActivity.this).removePref("instagram_field");
        MyPref.getInstance(HomeActivity.this).removePref("facebook_field");

        MyPref.getInstance(HomeActivity.this).removePref(AppConstants.imagePathResultTweet);
        MyPref.getInstance(HomeActivity.this).readPrefs(AppConstants.imagePathResultFacebook);
        MyPref.getInstance(HomeActivity.this).removePref(AppConstants.getImagePathResultInstagram);



    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        MyPref.getInstance(HomeActivity.this).removePref(AppConstants.SOCIAL_LOGIN);
    }

    public void pushFragment() {
        pushFragments(new MyCampaignsFragment(), null, false);
    }


}